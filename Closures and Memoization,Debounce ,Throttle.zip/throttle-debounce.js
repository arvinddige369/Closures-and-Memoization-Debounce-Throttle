const normal_dive = document.querySelector('.n_count');
const throttle_dive = document.querySelector('.t_count');
const debounce_div = document.querySelector('.d_count');
let n_cnt = 0;
let t_cnt = 0;
let d_cnt = 0;
let isScrolling = true;

// Normal count 

const normalCount = () => {
    n_cnt++;
    normal_dive.innerHTML = `normal count: ${n_cnt}`;
}

// throtal count 

const throtalCount = () => {
    if (isScrolling === true) {
        t_cnt++;
        throttle_dive.innerHTML = `Throttle count ${t_cnt}`;
        isScrolling = false;
        setTimeout(() => {
            isScrolling = true;
        }, 1000)
    }
}

// debounce count 

let interval;

const debounceCount = () => {
    clearTimeout(interval);
    interval = setTimeout(() => {
d_cnt++;
debounce_div.innerHTML = `debounce Count ${d_cnt}`;
}, 1000);
}



const showCount = () => {
    normalCount();
    throtalCount();
    debounceCount();
}