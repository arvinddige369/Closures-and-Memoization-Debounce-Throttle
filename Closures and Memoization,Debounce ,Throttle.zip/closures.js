
function countIncrees() {
    let count = 0;
    return function () {
        count = count + 1
        return count;
    }
}

const myInc = countIncrees();
console.log(myInc());
console.log(myInc());
console.log(myInc());
