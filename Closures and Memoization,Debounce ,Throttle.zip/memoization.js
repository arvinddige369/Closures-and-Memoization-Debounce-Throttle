function memoizationSeq() {
    const cashe = {};
    return function (n) {
        if (n in cashe) {
            console.log("return cashe");
            return cashe[n];
        }
        cashe[n] = n * n;
        console.log("return cashecalculet");
        return cashe[n];
    }

}

const memosqr = memoizationSeq();
console.log(memosqr(5));
console.log(memosqr(5));